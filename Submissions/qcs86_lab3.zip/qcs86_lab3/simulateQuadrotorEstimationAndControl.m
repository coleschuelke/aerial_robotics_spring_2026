function [Q, Est] = simulateQuadrotorEstimationAndControl(R,S,P)
% simulateQuadrotorEstimationAndControl : Simulates closed-loop estimation and
%                                         control of a quadrotor aircraft.
%
% INPUTS
%
% R ---------- Structure with the following elements:
%
%          tVec = Nx1 vector of uniformly-sampled time offsets from the
%                 initial time, in seconds, with tVec(1) = 0.
%
%        rIstar = Nx3 matrix of desired CM positions in the I frame, in
%                 meters.  rIstar(k,:)' is the 3x1 position at time tk =
%                 tVec(k).
%
%        vIstar = Nx3 matrix of desired CM velocities with respect to the I
%                 frame and expressed in the I frame, in meters/sec.
%                 vIstar(k,:)' is the 3x1 velocity at time tk = tVec(k).
%
%        aIstar = Nx3 matrix of desired CM accelerations with respect to the I
%                 frame and expressed in the I frame, in meters/sec^2.
%                 aIstar(k,:)' is the 3x1 acceleration at time tk =
%                 tVec(k).
%
%        xIstar = Nx3 matrix of desired body x-axis direction, expressed as a
%                 unit vector in the I frame. xIstar(k,:)' is the 3x1
%                 direction at time tk = tVec(k).
%  
% S ---------- Structure with the following elements:
%
%  oversampFact = Oversampling factor. Let dtIn = R.tVec(2) - R.tVec(1). Then
%                 the output sample interval will be dtOut =
%                 dtIn/oversampFact. Must satisfy oversampFact >= 1.
%
%        state0 = State of the quad at R.tVec(1) = 0, expressed as a structure
%                 with the following elements:
%                   
%                   r = 3x1 position in the world frame, in meters
% 
%                   e = 3x1 vector of Euler angles, in radians, indicating the
%                       attitude
%
%                   v = 3x1 velocity with respect to the world frame and
%                       expressed in the world frame, in meters per second.
%                 
%              omegaB = 3x1 angular rate vector expressed in the body frame,
%                       in radians per second.
%
%       distMat = (N-1)x3 matrix of disturbance forces acting on the quad's
%                 center of mass, expressed in Newtons in the I frame.
%                 distMat(k,:)' is the constant (zero-order-hold) 3x1
%                 disturbance vector acting on the quad from R.tVec(k) to
%                 R.tVec(k+1).
%
%        rXIMat = Nf-by-3 matrix of coordinates of visual features in the
%                 simulation environment, expressed in meters in the I
%                 frame. rXIMat(i,:)' is the 3x1 vector of coordinates of
%                 the ith feature.  
%
% P ---------- Structure with the following elements:
%
%    quadParams = Structure containing all relevant parameters for the
%                 quad, as defined in quadParamsScript.m 
%
%     constants = Structure containing constants used in simulation and
%                 control, as defined in constantsScript.m 
%
%  sensorParams = Structure containing sensor parameters, as defined in
%                 sensorParamsScript.m
%
%
% OUTPUTS
%
% Q ---------- Structure with the following elements:
%
%          tVec = Mx1 vector of output sample time points, in seconds, where
%                 Q.tVec(1) = R.tVec(1), Q.tVec(M) = R.tVec(N), and M =
%                 (N-1)*oversampFact + 1.
%  
%         state = State of the quad at times in tVec, expressed as a
%                 structure with the following elements:
%                   
%                rMat = Mx3 matrix composed such that rMat(k,:)' is the 3x1
%                       position at tVec(k) in the I frame, in meters.
% 
%                eMat = Mx3 matrix composed such that eMat(k,:)' is the 3x1
%                       vector of Euler angles at tVec(k), in radians,
%                       indicating the attitude.
%
%                vMat = Mx3 matrix composed such that vMat(k,:)' is the 3x1
%                       velocity at tVec(k) with respect to the I frame
%                       and expressed in the I frame, in meters per
%                       second.
%                 
%           omegaBMat = Mx3 matrix composed such that omegaBMat(k,:)' is the
%                       3x1 angular rate vector expressed in the body frame in
%                       radians, that applies at tVec(k).
% Est --------- Optional structure with the following elements:
%
%          tVec = Nx1 vector of output sample time points, in seconds, where
%                 Q.tVec(1) = R.tVec(1), Q.tVec(M) = R.tVec(N), and M =
%                 (N-1)*oversampFact + 1.
%  
%         state = Estimated state of the quad at times in tVec, expressed as a
%                 structure with the following elements:
%                   
%                rMat = Nx3 matrix composed such that rMat(k,:)' is the 3x1
%                       estimated position at tVec(k) in the I frame, in meters.
% 
%                eMat = Nx3 matrix composed such that eMat(k,:)' is the 3x1
%                       vector of estimated Euler angles at tVec(k), in radians,
%                       indicating the attitude.
%
%                vMat = Nx3 matrix composed such that vMat(k,:)' is the 3x1
%                       estimated velocity at tVec(k) with respect to the I frame
%                       and expressed in the I frame, in meters per
%                       second.
%                 
%           omegaBMat = Nx3 matrix composed such that omegaBMat(k,:)' is the
%                       3x1 estimated angular rate vector expressed in the body frame in
%                       radians, that applies at tVec(k).
%
%          PMat = nx-by-nx-by-N error covariance matrix for the estimator state
%                 vector xk, which is defined as 
% 
%                 xk = [rI', vI', e', ba', bg']'
%
%                 where all corresponding quantities are identical to those
%                 defined for Est.state and where e is the 3x1 error Euler
%                 angle vector defined such that for an estimate RBIHat of the
%                 attitude, the true attitude is RBI = D(e)*RBIHat, where D(e)
%                 is the DCM formed from the error Euler angle vector e.
%
%+------------------------------------------------------------------------------+
% References:
%
%
% Author: Quentin Schuelke
%+==============================================================================+  

%% Validate inputs
global INPUT_PARSING;
if INPUT_PARSING
  issize =@(x,z1,z2) validateattributes(x,{'numeric'},{'size',[z1,z2]});
  ip = inputParser; ip.StructExpand = true; ip.KeepUnmatched = true;
  ip.addParameter('tVec',[],@(x)issize(x,NaN,1));
  ip.addParameter('rIstar',[],@(x)issize(x,NaN,3));
  ip.addParameter('vIstar',[],@(x)issize(x,NaN,3));
  ip.addParameter('aIstar',[],@(x)issize(x,NaN,3));
  ip.addParameter('xIstar',[],@(x)issize(x,NaN,3));
  ip.addParameter('oversampFact',[],@(x)issize(x,1,1));
  ip.addParameter('distMat',[],@(x)issize(x,NaN,3));
  ip.addParameter('rXIMat',[],@(x)issize(x,NaN,NaN));
  ip.addParameter('r',[],@(x)issize(x,3,1));
  ip.addParameter('e',[],@(x)issize(x,3,1));
  ip.addParameter('v',[],@(x)issize(x,3,1));
  ip.addParameter('omegaB',[],@(x)issize(x,3,1));
  ip.addParameter('quadParams',[],@(x)isstruct(x));
  ip.addParameter('constants',[],@(x)isstruct(x));
  ip.addParameter('sensorParams',[],@(x)isstruct(x));
  ip.parse(R,S,S.state0,P);
  if sum(cellfun(@isempty,struct2cell(ip.Results)))~=0
    warning('Input empty or missing.');
  end
end

%% Setup
N = length(R.tVec);
dtIn = R.tVec(2) - R.tVec(1);
dtOut = dtIn/S.oversampFact;
RBIk = euler2dcm(S.state0.e);
omegaVec0 = zeros(4,1);
Xk = [S.state0.r;S.state0.v;RBIk(:);S.state0.omegaB;omegaVec0];
Xdotk = zeros(length(Xk),1);
statek.RBI = zeros(3,3);
[Nf,~] = size(S.rXIMat);
Se.rXIMat = S.rXIMat;
Se.delt = dtIn;
XMat = []; tVec = []; estMat = []; covMat = [];

%% Iterate through all time points
for kk=1:N-1
  % Pack the true state structure from the true state vector Xk
  statek.rI = Xk(1:3);
  statek.RBI(:) = Xk(7:15);
  statek.vI = Xk(4:6);
  statek.omegaB = Xk(16:18);
  statek.aI = Xdotk(4:6);
  statek.omegaBdot = Xdotk(16:18);
  Sm.statek = statek;
  % Simulate measurements
  M.tk=dtIn*(kk-1);
  [M.rpGtilde,M.rbGtilde] = gnssMeasSimulator(Sm,P);
  M.rxMat = [];
  for ii=1:Nf
    rx = hdCameraSimulator(S.rXIMat(ii,:)',Sm,P);
    if(isempty(rx))
      M.rxMat(ii,:) = [NaN,NaN];
    else
      M.rxMat(ii,:) = rx';
    end
  end
  [M.ftildeB,M.omegaBtilde] = imuSimulator(Sm,P);
  % Call estimator
  E = stateEstimatorUKF(Se,M,P);
  if nargout > 1
      EstVeck = [E.statek.rI; E.statek.RBI(:); E.statek.vI; E.statek.omegaB];
      estMat = [estMat; EstVeck.'];
      covMat = cat(3, covMat, E.Pk);
  end
  if(~isempty(E.statek))
    % Call trajectory and attitude controllers
    Rtc.rIstark = R.rIstar(kk,:)';
    Rtc.vIstark = R.vIstar(kk,:)';
    Rtc.aIstark = R.aIstar(kk,:)';
    Rac.xIstark = R.xIstar(kk,:)';
    distVeck = S.distMat(kk,:)';
    % Copy the estimated state, E.statek, into the controllers' S structure
    Sc.statek = E.statek;
    [Fk,Rac.zIstark] = trajectoryController(Rtc,Sc,P);
    NBk = attitudeController(Rac,Sc,P);
    % Convert commanded Fk and NBk to commanded voltages
    eaVeck = voltageConverter(Fk,NBk,P);
  else
    % Apply no control if state estimator's output is empty.  Set distVeck to
    % apply a normal force in the vertical direction that exactly offsets the
    % acceleration due to gravity.
    eaVeck = zeros(4,1);
    distVeck = [0;0;P.quadParams.m*P.constants.g];
  end
  tspan = [R.tVec(kk):dtOut:R.tVec(kk+1)]';
  [tVeck,XMatk] = ...
      ode45(@(t,X) quadOdeFunctionHF(t,X,eaVeck,distVeck,P),tspan,Xk);
  if(length(tspan) == 2)
    % Deal with S.oversampFact = 1 case 
    tVec = [tVec; tVeck(1)];
    XMat = [XMat; XMatk(1,:)];
  else
    tVec = [tVec; tVeck(1:end-1)];
    XMat = [XMat; XMatk(1:end-1,:)];
  end
  Xk = XMatk(end,:)';
  Xdotk = quadOdeFunctionHF(tVeck(end),Xk,eaVeck,distVeck,P);
  % Ensure that RBI remains orthogonal
  if(mod(kk,100) == 0)
   RBIk(:) = Xk(7:15);
   [UR,~,VR]=svd(RBIk);
   RBIk = UR*VR'; Xk(7:15) = RBIk(:);
  end
end
XMat = [XMat;XMatk(end,:)];
tVec = [tVec;tVeck(end,:)];

%% Package output
M = length(tVec);
Q.tVec = tVec;
Q.state.rMat = XMat(:,1:3);
Q.state.vMat = XMat(:,4:6);
Q.state.omegaBMat = XMat(:,16:18);
Q.state.eMat = zeros(M,3);
RBI = zeros(3,3);
for mm=1:M
  RBI(:) = XMat(mm,7:15);
  Q.state.eMat(mm,:) = dcm2euler(RBI)';  
end
if nargout > 1
    Est.state.eMat = zeros(size(estMat, 1), 3);
    for jj=1:size(estMat, 1)
        RBI(:) = estMat(jj, 4:12);
        Est.state.eMat(jj, :) = dcm2euler(RBI).';
    end
    Est.tVec = linspace(tVec(1), tVec(end), size(estMat, 1));
    Est.state.rMat = estMat(:, 1:3);
    Est.state.vMat = estMat(:, 13:15);
    Est.state.omegaBMat = estMat(:, 16:18);
    Est.PMat = covMat;
end
end
  

